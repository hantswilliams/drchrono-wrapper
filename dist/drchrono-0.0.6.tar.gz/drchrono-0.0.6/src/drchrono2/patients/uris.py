ROOT_API = 'drchrono.com/api'
ROOT_PATIENT_API = ROOT_API + '/patients'
